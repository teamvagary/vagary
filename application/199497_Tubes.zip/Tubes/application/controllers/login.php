<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	
	public function index()
	{
		$this->load->view('form_login');
	}

	function prosesLogin()
	{
		$email_user = $this->input->post('email', true);
		$pass_user = $this->input->post('pass', true);
		$cek = $this->login_model->ceklogin($email_user,$pass_user);
		$tes = count($cek);
		if ($tes > 0){
			$data_login = $this->login_model->ceklogin($email_user,$pass_user);
			$level = $data_login->level;
			$data = array('level' => $level);
			$this->session->set_userdata($data);
			if($level == 'admin'){
				redirect ('admin');
			}elseif($level == 'user'){
				redirect('user');
			}

		
		}else{
			echo 'gagal login';
		}

	}

	function signup()
	{
		$email_user = $this->input->post('email', true);
		$pass_user = $this->input->post('pass', true);
		$cekk = $this->login_model->cekloginn($email_user,$pass_user);
		$tess = count($cekk);
		if ($tess > 0){
			$data_login = $this->login_model->cekloginn($email_user,$pass_user);
			$level = $data_login->level;
			$data = array('level' => $level);
			$this->session->set_userdata($data);
			if($level == 'admin'){
				redirect ('admin');
			}elseif($level == 'user'){
				redirect('user');
			}

		
		}else{
			echo 'gagal login';
		}
		redirect('login');

	}


	function logout()
	{
		$this->session->sess_destroy();
		redirect('login');
	}
}
