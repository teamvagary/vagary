<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">

	<title></title>
</head>
<body>
<div class="container">
	<div class="col-md-9">
		<h3>Sign Up</h3>
		<hr>
		<form action="<?php echo base_url('login/signup')?>" method="post">
			<div class="form-group">
				<label>Email</label>
				<input type="email" name="email" class="form_control">
			</div>
			<div class="form-group">
				<label>Password</label>
				<input type="password" name="pass" class="form_control">
			</div>
			<input type="submit" class="btn btn-succes" value="Simpan">
		</form>
		
	</div>
	
</div>
</body>
</html>