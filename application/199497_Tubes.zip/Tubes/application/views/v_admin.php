<!DOCTYPE html>
<html>
<head>
	<title>Halaman admin</title>
</head>
<body>
Selamat datang admin <br>
<a href="<?php echo site_url('login/logout') ?>">Keluar</a>
</body>
</html>