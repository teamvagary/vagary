1. import database belajar melalui phpmyadmin
2. atur koneksi di application/config/database.php
3. load helper url dan database library di application/config/autoload.php
4. copykan controller, model dan view di folder application
5. jalankan melalui browser